// VARIABLES GLOBALES


// DOM READY
document.addEventListener("DOMContentLoaded", function() {
    console.log('ready');
});

// FUNCTIONS EXTERNES